// script.js - common functions for all pages

document.addEventListener("DOMContentLoaded", () => {
  // Show logout link if logged in
  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) {
    if (localStorage.getItem("isLoggedIn")) {
      logoutLink.style.display = "block";
      logoutLink.addEventListener("click", () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userEmail");
        alert("You have been logged out.");
        window.location.href = "login.html";
      });
    } else {
      logoutLink.style.display = "none";
    }
  }
});

// Booking handler - basic validation + price calc + show summary
function bookNow(e) {
  e.preventDefault();

  // read form values (IDs used in booking.html)
  const name = document.getElementById('bName').value.trim();
  const email = document.getElementById('bEmail').value.trim();
  const checkin = document.getElementById('bCheckin').value;
  const checkout = document.getElementById('bCheckout').value;
  const roomValue = document.getElementById('bRoom').value;
  const note = document.getElementById('bNote').value.trim();

  if (!name || !email || !checkin || !checkout || !roomValue) {
    alert("Please complete all required fields.");
    return false;
  }

  // calculate nights
  const d1 = new Date(checkin);
  const d2 = new Date(checkout);
  const diff = (d2 - d1) / (1000*60*60*24);
  if (isNaN(diff) || diff <= 0) {
    alert("Please select valid check-in and check-out dates (check-out must be after check-in).");
    return false;
  }

  // roomValue format: "Name|price"
  const [roomName, rate] = roomValue.split('|');
  const nights = diff;
  const total = nights * Number(rate);

  // store booking in localStorage as a simple array (optional)
  const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
  const booking = { name, email, checkin, checkout, roomName, nights, rate: Number(rate), total, note, created: new Date().toISOString() };
  bookings.push(booking);
  localStorage.setItem('bookings', JSON.stringify(bookings));

  // show confirmation
  alert(`Booking Confirmed!\n\nName: ${name}\nRoom: ${roomName}\nNights: ${nights}\nTotal: $${total.toFixed(2)}\n\nThank you!`);
  document.getElementById('bookingForm').reset();
  return false;
}

// Feedback handler
function sendFeedback(e) {
  e.preventDefault();
  const name = document.getElementById('fName').value.trim();
  const email = document.getElementById('fEmail').value.trim();
  const message = document.getElementById('fMessage').value.trim();
  if (!name || !email || !message) {
    alert("Please complete all fields.");
    return false;
  }

  // store feedback in localStorage (simple)
  const feedbacks = JSON.parse(localStorage.getItem('feedbacks') || '[]');
  feedbacks.push({ name, email, message, created: new Date().toISOString() });
  localStorage.setItem('feedbacks', JSON.stringify(feedbacks));

  alert("Thanks for your feedback! We appreciate it.");
  document.getElementById('feedbackForm')?.reset();
  return false;
}

// Contact submit (contact.html)
function contactSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('cName').value.trim();
  const email = document.getElementById('cEmail').value.trim();
  const msg = document.getElementById('cMessage').value.trim();
  if (!name || !email || !msg) {
    alert("Please fill all fields.");
    return false;
  }
  alert("Thank you! Your message has been sent.");
  document.getElementById('contactForm')?.reset();
  return false;
}
document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) {
    if (localStorage.getItem("isLoggedIn")) {
      logoutLink.style.display = "block";
      logoutLink.addEventListener("click", () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userEmail");
        alert("You have logged out successfully!");
        window.location.href = "login.html";
      });
    } else {
      logoutLink.style.display = "none";
    }
  }
});
